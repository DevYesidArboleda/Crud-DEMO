<?php $__env->startSection('content'); ?>
 <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h3 class="text-center">Bienvenido !!</h3>
                    
                    <div class="pull-right">
                        <a class="btn btn-success"  data-toggle="modal" data-target="#myModal">
                        <i class="fa fa-upload"></i>
                        Cargar comprobante
                    </a>
                    </div>
            <!-- Modal -->
            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Cargar comprobante</h4>
                  </div>
                  <div class="modal-body">
                    <form method="POST" class="form-horizontal" action="/public" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?><!--- El helper csrf_field() imprime un campo de tipo hidden que contiene un hash utilizado para proteger a la aplicación contra ataques CSRF. -->
                        <div class="form-group">
                          <label for="codigo" class="col-md-4 control-label">codigo</label>
                          <div class="col-md-6">
                            <input type="text" class="form-control" id="codigo" name="codigo" placeholder="Codigo.." />

                              <?php if($errors->has('codigo')): ?>
                              <span style="color: red;"><?php echo e($errors->first('codigo')); ?></span>

                              <?php endif; ?>

                          </div>
                        </div>
                        <div class="form-group">
                          <label for="" class="col-md-4 control-label">Nuevo archivo</label>
                          <div class="col-md-6">
                            <input type="file" name="file" id="file" class="form-control" />
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-6 col-md-offset-4">
                            <button type="submit" class="btn btn-primary pull-right">Enviar</button>
                          </div>
                          
                        </div>
                    </form>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
                </div>

              </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>