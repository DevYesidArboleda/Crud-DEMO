<nav class="navbar navbar-default navbar-static-top">
  <div class="container">
      <div class="navbar-header">

          <!-- Collapsed Hamburger -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
              <span class="sr-only">Toggle Navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
          </button>

          <!-- Branding Image -->
          <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
              Inicio
          </a>
      </div>

      <div class="collapse navbar-collapse" id="app-navbar-collapse">  
          <!-- Left Side Of Navbar -->
          <ul class="nav navbar-nav">
    			
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Afiliaciones <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(url('/affiliations/company')); ?>">A nuestra empresa</a></li>
                  <li><a href="<?php echo e(url('/affiliations/social-security')); ?>">Seguridad social</a></li>
                  <li><a href="<?php echo e(url('/affiliations/prepaid-medicine')); ?>">Medicina prepagada</a></li>
                  <li><a href="<?php echo e(url('/affiliations/specialists-plan')); ?>">Planes especialistas</a></li>
                  <li><a href="<?php echo e(url('/affiliations/complementary-plan')); ?>">Planes complementario</a></li>
                  <li><a href="<?php echo e(url('/affiliations/exequial-plan')); ?>">Planes exequiales</a></li>
                </ul>
              </li>
              <li><a href="<?php echo e(url('/work-with-us')); ?>">Trabaja con nosotros</a></li>
          </ul>

          <!-- Right Side Of Navbar -->
          <ul class="nav navbar-nav navbar-right">
              <!-- Authentication Links -->
              <?php if(Route::has('login')): ?>
					        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                  <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
					    <?php endif; ?>
          </ul>
      </div>
  </div>
</nav>