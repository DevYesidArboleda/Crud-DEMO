<nav class="navbar navbar-default navbar-static-top">
  <div class="container">
      <div class="navbar-header">

          <!-- Collapsed Hamburger -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
              <span class="sr-only">Toggle Navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
          </button>

          <!-- Branding Image -->
          <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
              Inicio
          </a>
      </div>

      <div class="collapse navbar-collapse" id="app-navbar-collapse">  
          <!-- Left Side Of Navbar -->
          <ul class="nav navbar-nav">
    			
              <li class="dropdown">
               <a href="<?php echo e(url('/affiliations')); ?>"> Afiliaciones</a>
              </li>
              <li><a href="<?php echo e(url('/work-with-us')); ?>">Trabaja con nosotros</a></li>
          </ul>

          <!-- Right Side Of Navbar -->
          <ul class="nav navbar-nav navbar-right">
              <!-- Authentication Links -->
              <?php if(Route::has('login')): ?>
					        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                  <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
					    <?php endif; ?>
          </ul>
      </div>
  </div>
</nav>