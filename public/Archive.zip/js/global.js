$(document).ready(function(){
	$(".checkbox_state").bootstrapSwitch();
});